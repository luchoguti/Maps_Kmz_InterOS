<?php
error_log('luis public 1');
header('Location: /public.php');
exit;
