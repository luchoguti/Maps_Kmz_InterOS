<?php
header('Location: /public.php');
exit;
